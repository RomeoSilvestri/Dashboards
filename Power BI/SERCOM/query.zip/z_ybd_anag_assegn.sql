--ANAG ASSEGNATARIO
CREATE or ALTER VIEW [dbo].[z_ybd_anag_assegn] as
select distinct
	case 
	when upper(anag_user_inf.COTITLE) is null then 'undefined'
	else upper(anag_user_inf.COTITLE)
	end as assegnatario
from [inf41_sercom].[dbo].cm_opportunity001 as opp
left join [inf41_sercom].[dbo].ba_contact as anag_user_inf
	on anag_user_inf.COCOMPANYID = opp.OPASSIGNEE
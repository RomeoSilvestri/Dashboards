CREATE or ALTER VIEW [dbo].[z_ybd_anag_fonti] as
SELECT distinct
	anag_camp.origine_bi
	--,anag_camp.origine
	--,anag_camp.descrizione_origine
 FROM [BI].[dbo].[z_ybd_pipeline] as anag_camp

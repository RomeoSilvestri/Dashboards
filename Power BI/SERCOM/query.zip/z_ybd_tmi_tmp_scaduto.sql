--TMI/TMP/SCADUTO
-- aggiungere colonna tempo pagamento e tempo incasso, con data emissione fattura e non data scadenza
CREATE or ALTER VIEW [dbo].[z_ybd_tmi_tmp_scaduto] as
select 
	part.PymtSchedId as id_partita
	,part_det.InstallmentNo as num_rate
	,part.LogNo -- chiave id documento di acquisto
	,part.DocNo
	,part.CustSupp as id_customer
	--,part.CustSuppType
	,case 
		when part.CustSuppType = 3211265 then 'Fornitore'
		when part.CustSuppType = 3211264 then 'Cliente' 
		else 'undefined'
	end as customer
	,cust.CompanyName 
	,part.DocumentDate as data_emiss_fatt
	,part_det.OpeningDate as data_scadenza
	,case 
		when part_det.PaymentTerm = 2686981 then part_det2.OpeningDate
		else part_det2.InstallmentDate 
	end as data_incasso
	,case 
		when (case when part_det.PaymentTerm = 2686981 then part_det2.OpeningDate else part_det2.InstallmentDate end) is null then 'Aperto' 
		else 'Chiuso' 
		end as stato_partita
	,case 
		when (case when part_det.PaymentTerm = 2686981 then part_det2.OpeningDate else part_det2.InstallmentDate end) is null and DATEDIFF(day,GETDATE(),part_det.OpeningDate) >= 0 then 'In Tempo' 
		when DATEDIFF(day,(case when part_det.PaymentTerm = 2686981 then part_det2.OpeningDate else part_det2.InstallmentDate end),part_det.OpeningDate) >= 0 then 'In Tempo' 
		else 'In ritardo'
		end as stato_pagamento
	,case 
	when (case 
		--caso 'In Tempo' 
		when (case when part_det.PaymentTerm = 2686981 then part_det2.OpeningDate else part_det2.InstallmentDate end) is null and DATEDIFF(day,GETDATE(),part_det.OpeningDate) >= 0 then 'In Tempo' 
		when DATEDIFF(day,(case when part_det.PaymentTerm = 2686981 then part_det2.OpeningDate else part_det2.InstallmentDate end),part_det.OpeningDate) >= 0 then 'In Tempo' 
		--caso 'In ritardo' ma data incasso a null --> differenza scadenza e oggi
		else 'In ritardo' end) = 'In ritardo' and (case when part_det.PaymentTerm = 2686981 then part_det2.OpeningDate else part_det2.InstallmentDate end) is null then abs(DATEDIFF(day,GETDATE(), part_det.OpeningDate))
	when (case 
		--caso 'In Tempo' 
		when (case when part_det.PaymentTerm = 2686981 then part_det2.OpeningDate else part_det2.InstallmentDate end) is null and DATEDIFF(day,GETDATE(),part_det.OpeningDate) >= 0 then 'In Tempo' 
		when DATEDIFF(day,(case when part_det.PaymentTerm = 2686981 then part_det2.OpeningDate else part_det2.InstallmentDate end),part_det.OpeningDate) >= 0 then 'In Tempo' 
		--caso 'In ritardo' ma data incasso NON null --> differenza scadenza e data incasso
		else 'In ritardo'end) = 'In ritardo' and (case when part_det.PaymentTerm = 2686981 then part_det2.OpeningDate else part_det2.InstallmentDate  end) is not null then abs(DATEDIFF(day,(case when part_det.PaymentTerm = 2686981 then part_det2.OpeningDate else part_det2.InstallmentDate end), part_det.OpeningDate))
		else null
	end as giorni_ritardo
	,case
		--when (case when part_det.PaymentTerm = 2686981 then part_det2.OpeningDate else part_det2.InstallmentDate end) is null then DATEDIFF(day,part.DocumentDate,GETDATE())
		--when (case when part_det.PaymentTerm = 2686981 then part_det2.OpeningDate else part_det2.InstallmentDate end) is not null 
		--then
		--DATEDIFF(day,part.DocumentDate,(case when part_det.PaymentTerm = 2686981 then part_det2.OpeningDate else part_det2.InstallmentDate end))
		--else null
	--end as giorni_chiusura
    WHEN DATEDIFF(day, part.DocumentDate, (CASE WHEN part_det.PaymentTerm = 2686981 THEN part_det2.OpeningDate ELSE part_det2.InstallmentDate END)) < 0 THEN 0
    ELSE DATEDIFF(day, part.DocumentDate, (CASE WHEN part_det.PaymentTerm = 2686981 THEN part_det2.OpeningDate ELSE part_det2.InstallmentDate END))
	END AS giorni_chiusura
	,part_det.PaymentTerm as tipo_pagamento
	,case
		when part_det.ClosingType = 6946816 then 'rata'
		else 'riapertura'
	end as tipo_rata
	,part.TotalAmount as importo_totale
	,case 
		when part_det.DebitCreditSign = 4980736 then 1	else -1 end *
	case
		when part.CustSuppType = 3211264 then 1	else -1 end *
		part_det.Amount 
		as importo_apertura
	,case 
		when part_det2.DebitCreditSign = 4980737 then 1	else -1 end *
	case
		when part.CustSuppType = 3211264 then 1	else -1 end *
		part_det2.Amount 
		as importo_chiusura
	-- nr fatture scaduti 
	-- importo fatture scadute
from [SERCOM].[dbo].MA_PyblsRcvbls as part
inner join [SERCOM].[dbo].MA_PyblsRcvblsDetails as part_det
	ON part.PymtSchedId = part_det.PymtSchedId
	and part_det.InstallmentType = 5505024
left join [SERCOM].[dbo].MA_PyblsRcvblsDetails as part_det2
	ON part.PymtSchedId = part_det2.PymtSchedId
	and part_det2.InstallmentType = 5505025
	and part_det2.InstallmentNo = part_det.InstallmentNo
left join [SERCOM].[dbo].[MA_CustSupp] as cust
	on cust.CustSupp = part.CustSupp
	and cust.CustSuppType = part.CustSuppType
where part.CustSuppType in (3211264, 3211265)
	and YEAR(part.DocumentDate) >= 2018
	--and part_det.PymtSchedId = 6053
	--and part_det.ClosingType != 6946816
	--and part.CustSuppType = 3211265
--order by part.DocumentDate desc
	


--PIPELINE
CREATE or ALTER VIEW [dbo].[z_ybd_pipeline] as
select distinct
	opp.OPOPPID as id_trattativa
	,case
		when opp.OPOPPTYPE = 1 then '2.Potenziale'
		when opp.OPOPPTYPE = 2 then '3.Opportunit�'
		when opp.OPOPPTYPE = 4 then '1.Lead'
		else 'undefined'
	end as tipo_trattativa
	--,brief.id_brief
	,case
		when brief.id_brief is null then 0
		else 1
	end as brief
	,brief.id_tipologia as tipologia_brief
	,opp.OPDTTAKING as data_apertura
	,brief.data_apertura_brief
	,brief.presa_in_carico as data_inizio_lav_brief
	,case
		when (brief.data_apertura_brief is not null and brief.presa_in_carico is not null) then DATEDIFF(day,brief.data_apertura_brief,brief.presa_in_carico) 
		--when (brief.data_apertura_brief is not null and brief.presa_in_carico is null) then DATEDIFF(day,GETDATE(),brief.data_apertura_brief)
		else null
		end as gg_presa_brief
		--DATEDIFF(day, (SELECT MAX(doc_det2.DocumentDate) 
	,opp.OPDTCLOSING as data_chiusura
	,opp.OPDTPREVCLOS as data_prev_chiusura
	,camp.CADESCRI as campagna
	,opp.OPSOURCE as origine
	,categ.CADESCRI as descrizione_origine
	,case 
		when anag_lead.KPI_Marketing is null then 'undefined' 
		else anag_lead.KPI_Marketing
		end as origine_bi
	--,stato_lead.LSTYPE as id_stato_lead
	,case 
		when stato_lead.LSTYPE = 10 then '01.Stato Iniziale'
		when stato_lead.LSTYPE = 20 then '02.In Corso'
		when stato_lead.LSTYPE = 30 then '03.Positivo'
		when stato_lead.LSTYPE = 40 and stato_lead.LSID = '_LEA_00004' then '04.Negativo_Non_Interessato'
		when stato_lead.LSTYPE = 40 and stato_lead.LSID <> '_LEA_00004' then '04.Negativo_Chiusa'
		when stato_lead.LSTYPE = 50 then '05.Sospesi'
		else 'undefined' 
	end as stato_lead
	--il 40 splitta con non interessato e chiusa (_LEA_00004 controlla che sia sempre cos�)
	,stato_lead.LSID as id_descrizione_stato
	,stato_lead.LSDESCRI as descrizione_stato
	,case 
		when upper(anag_user_inf.COTITLE) is null then 'undefined'
		else upper(anag_user_inf.COTITLE)
	end as assegnatario
	--commerciale
	--,anag_age.KSCODSOG as id_sales_pers
	,upper(brief.assegnatario_backoff) as assegnatario_backoff
	,opp.OPAMOUNT as amount
	,case 
		when stato_lead.LSTYPE = 30 then 1
		else null
	end as Nr_Vinte	
	,case 
		when stato_lead.LSTYPE = 30 then opp.OPAMOUNT
		else null
	end as Amount_Vinte
	,case 
		when stato_lead.LSTYPE = 40 and stato_lead.LSID = '_LEA_00004' then 1
		else null
	end as Nr_Non_Inter
	,case 
		when stato_lead.LSTYPE = 40 and stato_lead.LSID = '_LEA_00004' then opp.OPAMOUNT
		else null
	end as Amount_Non_Inter
	,case 
		when stato_lead.LSTYPE = 40 and stato_lead.LSID <> '_LEA_00004' then 1
		else null
	end as Nr_Chiuse
	,case 
		when stato_lead.LSTYPE = 40 and stato_lead.LSID <> '_LEA_00004' then opp.OPAMOUNT
		else null
	end as Amount_Chiuse
	,case 
		when stato_lead.LSTYPE in (10,20,50) then 1
		else null
	end as Nr_StandBy
	,case 
		when stato_lead.LSTYPE in (10,20,50) then opp.OPAMOUNT
		else null
	end as Amount_StandBy
from [inf41_sercom].[dbo].cm_opportunity001 as opp
left join [inf41_sercom].[dbo].cm_stateleads as stato_lead
	on stato_lead.LSID = opp.OPSTAGE
left join [inf41_sercom].[dbo].ba_contact as anag_user_inf
	on anag_user_inf.COCOMPANYID = opp.OPASSIGNEE
left join [inf41_sercom].[dbo].ba_keysog001 as anag_age
	on anag_age.KSCODCOM = opp.OPASSIGNEE and anag_age.KSTIPSOG = 'age'
left join [inf41_sercom].[dbo].ba_categories as categ
	on categ.CAID = opp.OPSOURCE and categ.CAMACRO = 'SOURCE'
left join [inf41_sercom].[dbo].cm_campagne001 as camp
	on camp.CACODICE = opp.OPAMPAGN
--BRIEF------------------------------
left join (select distinct
	attr.TTASKID as id_brief
	,attr.TTVALUE as id_trattativa
	,dett_brief.IDTIPOLOGIA as id_tipologia
	--,part.PLPERSONID as assegnatario_brief
	,task.TETITLE as task
	--,cont.COTITLE as nome_assegnatario
	,sub_q.presa_in_carico
	,apertura.PNDATREG as data_apertura_brief
	,sub_q.utente as assegnatario_backoff
	--,sub_q.utente_creat
from [inf41_sercom].[dbo].cl_task_target as attr
left join [inf41_sercom].[dbo].cl_tasks as task
	on task.TETASKID = attr.TTASKID
left join [inf41_sercom].[dbo].cl_tasktype as attr_type
	on task.TETYPE = attr_type.TTCODTIP
left join [inf41_sercom].[dbo].tbm_ainfo_dett as dett_brief
	on dett_brief.IDTASKID = attr.TTASKID
left join [inf41_sercom].[dbo].cl_participlist as part
	on part.PLTASKID = attr.TTASKID
left join [inf41_sercom].[dbo].ba_contact as cont
	on cont.COCOMPANYID = part.PLPERSONID
left join (select 
			azioni_tratt.PNCODTRA as id_tratt
			,min(azioni_tratt.PNDATREG) as presa_in_carico
			,min(azioni_tratt.PNPERCRE) as utente_creat
			,min(cont.COTITLE) as utente
		from [inf41_sercom].[dbo].cm_pntcrm001 as azioni_tratt
		left join [inf41_sercom].[dbo].cm_stateleads001 as _state
			on _state.LSID = azioni_tratt.PNSTAATT
		left join [inf41_sercom].[dbo].ba_contact as cont
			on cont.COCOMPANYID = azioni_tratt.PNPERCRE
		where (_state.LSDESCRI like '%preso%in%carico%' or _state.LSDESCRI like '%brief%in%corso%')
			--and azioni_tratt.PNCODTRA = '0000010595'
		group by azioni_tratt.PNCODTRA) as sub_q
		ON sub_q.id_tratt = attr.TTVALUE
		inner join [inf41_sercom].[dbo].cm_pntcrm001 as apertura
			on apertura.PNTASKID = attr.TTASKID and apertura.PNCAUCRM like 'PianInt%'
		where attr.TTARGETID = 'OPP'
			and attr_type.TTIPOATT = 'RC'
		) as brief
		on brief.id_trattativa = opp.OPOPPID
--OCCHIO ALLA TABELLA
left join BI.dbo.ybd_anag_fonti_lead as anag_lead
	on categ.CADESCRI = anag_lead.Descrizione
--order by opp.OPDTTAKING desc

--cm_opportunity001
--OPOPPTYPE --> POTENZIALE(1)/OPPORTUNITA'(2)/LEAD(4)
--OPDTTAKING --> DATA APERTURA
--OPDTCLOSING --> DATA CHIUSURA
--OPSTAGE --> CHIAVE PER LEGARSI E VEDERE STATO
--OPASSIGNEE --> 

--cm_stateleads
--LSTYPE --> 10 STATO INIZIALE, 20 IN CORSO, 30 POSITIVO, 40 NEGATIVO, 50 SOSPESI

/*
select distinct
	stato_lead.LSTYPE as stato_lead
	,stato_lead.LSDESCRI as descrizione_stato
	,stato_lead.LSID as stato
from cm_stateleads as stato_lead
order by stato_lead.LSTYPE desc 
*/
CREATE or ALTER VIEW [dbo].[z_ybd_previsionale] as
select 
	fatt.data_fatturazione as data_previsionale
	,sum(fatt.fatt_senza_sconto) as previsionale
from  [BI].[dbo].z_ybd_fatturato as fatt
group by fatt.data_fatturazione
union 
select 
	ord.data_ordine as data_previsionale
	,sum(ord.residuo) as previsionale
from  [BI].[dbo].z_ybd_ordinato as ord
group by ord.data_ordine


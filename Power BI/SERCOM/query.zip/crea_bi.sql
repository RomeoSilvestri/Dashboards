CREATE DATABASE BI;
 
CREATE TABLE ybd_anag_fonti_lead (
    KPI_Marketing VARCHAR(255),
    Codice VARCHAR(255),
    Descrizione VARCHAR(255),
    Categoria_padre VARCHAR(255) NULL
);
 
CREATE TABLE ybd_lead (
    data VARCHAR(255),
    KPI_Marketing VARCHAR(255),
);
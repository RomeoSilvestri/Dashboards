CREATE or ALTER VIEW [dbo].[z_ybd_anag_customer_type] as
select distinct
	case 
		when part.CustSuppType = 3211265 then 'Fornitore'
		when part.CustSuppType = 3211264 then 'Cliente' 
		else 'undefined'
		end as customer
from [SERCOM].[dbo].MA_PyblsRcvbls as part

CREATE or alter VIEW [dbo].[z_ybd_anag_calendar] AS
SELECT DateValue
FROM (
    SELECT TOP (DATEDIFF(DAY, '2018-01-01', GETDATE()) + 730)
           DateValue = DATEADD(DAY, ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1, '2018-01-01')
    FROM master.dbo.spt_values
) AS DateGenerator 

--FATTURATO KPI 1
CREATE or ALTER VIEW [dbo].[z_ybd_fatturato] as
select 
	doc_det.SaleDocId as id_doc
	,LineType as id_LineType
	,doc.DocNo
	,sale_peop.Name
	,case 
		when LineType = 3538946 then 'Servizio'
		when LineType = 3538947 then 'Merce'
		else 'Altro'
	end as tipo_vendita
	,Item as item
	,Description as descrizione_item
	,case
		when (sale_ord.TBMW_TipoBusiness = '' or sale_ord.TBMW_TipoBusiness is null) then 'undefined'
		else sale_ord.TBMW_TipoBusiness
	end as business_unit
	,doc.DocumentDate as data_fatturazione
	,case 
		when doc.DocumentType = 3407874 then 'Fatture immediata con DDT'
		when doc.DocumentType = 3407875 then 'Fatture accompagnatorie senza DDT' 
		when doc.DocumentType = 3407876 then 'Nota credito'
		else 'undefined'
	end as tipo_documento
	,doc.CustSupp as id_customer
	,case 
		when doc.CustSuppType = 3211265 then 'Fornitore'
		when doc.CustSuppType = 3211264 then 'Cliente' 
		else 'undefined'
	end as customer
	,cust.CompanyName as nome_customer
	,doc_det.TaxableAmount as fatt_full
	,DistributedDiscount as sconto
	,doc_det.TaxableAmount - DistributedDiscount as fatt_senza_sconto
	,(doc_summ.ShippingCharges+ doc_summ.CollectionCharges+doc_summ.StampsCharges+doc_summ.PackagingCharges+doc_summ.AdditionalCharges) as oneri_accessori
	-- doc_det.TaxableAmount:oneri=fatt_full:x
	,case 
		when
		ISNULL(DATEDIFF(day, (SELECT MAX(doc_det2.DocumentDate) 
			FROM [SERCOM].[dbo].[MA_SaleDocDetail] AS doc_det2
			left join [SERCOM].[dbo].[MA_SaleDoc] as doc2
				on doc_det2.SaleDocId = doc2.SaleDocId
				WHERE 
					doc2.CustSupp = doc.CustSupp 
					and doc2.CustSuppType = doc.CustSuppType
					AND doc2.DocumentType in (3407874, 3407875, 3407876)
					and Item not in ('X', 'TRASPORTO')
				AND doc_det2.DocumentDate < doc_det.DocumentDate), 
		doc.DocumentDate),9999) > 540 then 'Nuovo'
		else 'Rinnovo'
	end AS fidelizzazione
from [SERCOM].[dbo].[MA_SaleDocDetail] as doc_det
inner join [SERCOM].[dbo].[MA_SaleDoc] as doc
	on doc_det.SaleDocId = doc.SaleDocId
inner join [SERCOM].[dbo].[MA_SaleDocSummary] as doc_summ
	on doc_summ.SaleDocId = doc.SaleDocId
left join [SERCOM].[dbo].[MA_SaleOrd] as sale_ord
	on sale_ord.SaleOrdId = doc_det.SaleOrdId
left join [SERCOM].[dbo].[MA_CustSupp] as cust
	on doc.CustSupp = cust.CustSupp
	and doc.CustSuppType = cust.CustSuppType
left join [SERCOM].[dbo].[MA_SalesPeople] as sale_peop
	on sale_peop.Salesperson = doc.Salesperson
where 
	doc.DocumentType in (3407874, 3407875, 3407876)
	and Item not in ('X', 'TRASPORTO')
	--and doc_det.SaleDocId = 21884
	--and sale_ord.SaleOrdId = 9101
	--and doc.CustSupp= 000371
--order by doc.DocumentDate asc




-- ShippingCharges --> Spese spedizione
-- CollectionCharges --> spese incasso
-- StampsCharges --> spese bolli
-- PackagingCharges --> spese imballo
-- AdditionalCharges --> spese accessorie


--SaleType
--3670016 --> omaggio totale
--3670019 --> sconto merce
--3670018 --> promozione
--3670017 --> omaggio imponibile
--3670020 --> normale
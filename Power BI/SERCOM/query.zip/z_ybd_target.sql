--TARGET
CREATE or ALTER VIEW [dbo].[z_ybd_target] as
select 
	target_acc.TATIPAGE
	,sales_peop.Salesperson as id_person
	,sales_peop.Name as sales_person
	,sales_peop.HiringDate as data_assunzione
	,sales_peop.FiringDate as data_cessazione
	,sales_peop.Disabled as dipendente
	,target_acc.TACODESE as anno_target
	,target_acc.TAIMPORTO - target_acc.TANEWBUS as target_rinnovo
	,target_acc.TANEWBUS as target_nuovo
	,target_acc.TAIMPORTO as target_totale
from [inf41_sercom].[dbo].tbm_target001 as target_acc
left join [SERCOM].[dbo].[MA_SalesPeople] as sales_peop
	on target_acc.TACODAGE = sales_peop.Salesperson
--where target_acc.TACODESE = 2021
--order by TACODESE



--TACODAGE --> SALE PERSON MAGO
--TATIPAGE --> 
--TAIMPORT --> IMPORTO TARGET TOTALE
--TANEWBUS --> DI CUI NUOVO

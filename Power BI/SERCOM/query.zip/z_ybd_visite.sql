--VISITE
CREATE or ALTER VIEW [dbo].[z_ybd_visite] as
select 
	attr.TTASKID as id_brief
	,attr.TTVALUE as id_trattativa
	--,part.PLPERSONID as assegnatario_brief
	,task.TETITLE as task
	,task.TETYPE as tipo
	,attr_type.TTDESCRI as descrizione
	,task.TEPREVEND as data_visita
	,case 
		when task.TEPREVEND > GETDATE() then 'Pianificata'
		else 'Effettuata'
	end as stato_visita
from [inf41_sercom].[dbo].cl_task_target as attr
left join [inf41_sercom].[dbo].cl_tasks as task
	on task.TETASKID = attr.TTASKID
left join [inf41_sercom].[dbo].cl_tasktype as attr_type
	on task.TETYPE = attr_type.TTCODTIP
where attr.TTARGETID = 'OPP'
	and isnull(attr_type.TTIPOATT,' ') <> 'RC'
	and task.TECLASSE = 'E'
	--and attr.TTVALUE = '0000010530'
	and attr_type.TTDESCRI like '%Appuntamento%Commerciale%'
	--and YEAR(task.TEPREVEND) >= '2023'

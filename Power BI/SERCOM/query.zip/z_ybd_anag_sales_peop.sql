CREATE or ALTER VIEW [dbo].[z_ybd_anag_sales_peop] as
select distinct
	sale_peop.Name
from [SERCOM].[dbo].[MA_SalesPeople] as sale_peop
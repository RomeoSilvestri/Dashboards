--ORDINATO KPI 2
--aggiungi rinnovo
CREATE or ALTER VIEW [dbo].[z_ybd_ordinato] as
select
	ord.SaleOrdId
	,ord.Customer as cliente
	,case 
		when ord.CustSuppType = 3211265 then 'Fornitore'
		when ord.CustSuppType = 3211264 then 'Cliente' 
		else 'undefined'
	end as customer
	,cust.CompanyName 
	,ord.OrderDate as data_ordine
	,ord.InternalOrdNo
	,ord.SaleType
	,case
		when (ord.TBMW_TipoBusiness = '' or ord.TBMW_TipoBusiness is null) then 'undefined'
		else ord.TBMW_TipoBusiness
	end as business_unit
	,sale_peop.Name
	,case 
		when ord_det.LineType = 3538946 then 'Servizio'
		when ord_det.LineType = 3538947 then 'Merce'
		else 'Altro' 
	end as tipo_vendita
	,ord_det.Item as item
	,ord_det.Description as descrizione_item
	,ord_det.Qty as qty_ordinata
	,ord_det.DeliveredQty as qty_consegnata
	,case
		when ord_det.Delivered = '0' then 'Aperto'
		else 'Chiuso'
	end as stato_ordine
	,ord_det.InvoicedQty as qty_fatturata
	,ord_det.Invoiced as ordine_fatturato
	,ord_det.TaxableAmount as tot_fatt
	,(ord_det.Qty - ord_det.DeliveredQty ) * ( ( ord_det.NetPrice * ( 1 - ( ord_summ.Discounts / NULLIF((ord_summ.GoodsAmount + ord_summ.ServiceAmounts),0) ) ) ) ) as residuo
	,case 
		when
		ISNULL(DATEDIFF(day, (SELECT MAX(ord2.OrderDate) 
			FROM  [SERCOM].[dbo].[MA_SaleOrd] as ord2
				WHERE 
					ord2.Customer = ord.Customer
					and ord2.CustSuppType = ord.CustSuppType
					AND ord.SaleType in (3670018,3670019,3670020)
					and Item not in ('X', 'TRASPORTO')
				AND ord2.OrderDate < ord.OrderDate), 
		ord.OrderDate),9999) > 540 then 'Nuovo'
		else 'Rinnovo'
	end AS fidelizzazione
from  [SERCOM].[dbo].[MA_SaleOrd] as ord
inner join  [SERCOM].[dbo].[MA_SaleOrdDetails] as ord_det
	ON ORD.SaleOrdId = ord_det.SaleOrdId
inner join  [SERCOM].[dbo].[MA_SaleOrdSummary] as ord_summ
	on ord_summ.SaleOrdId = ord_det.SaleOrdId
left join  [SERCOM].[dbo].[MA_CustSupp] as cust
	on cust.CustSupp = ord.Customer
	and cust.CustSuppType = ord.CustSuppType
left join  [SERCOM].[dbo].[MA_SalesPeople] as sale_peop
	on sale_peop.Salesperson = ord.Salesperson
where ord_det.Cancelled = '0'
	and ord.Cancelled = '0'
	--and ord_det.Delivered = '0'
	and Item not in ('X', 'TRASPORTO')
	and ord.SaleType in (3670018,3670019,3670020)
	--and ord.Customer = 001902
--order by ord.OrderDate desc

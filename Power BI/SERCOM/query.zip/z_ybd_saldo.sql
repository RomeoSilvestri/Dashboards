--SALDO
CREATE or ALTER VIEW [dbo].[z_ybd_saldo] as
select
	DATEFROMPARTS(BalanceYear, BalanceMonth, 1) as periodo
	,FiscalYear
	,BalanceYear
	,BalanceMonth
	,BalanceType
	,Debit as entrate
	,Credit as uscite
	--,case
		--when BalanceYear = 2023 and BalanceType = 3145728 then (Debit - Credit)
		--else 0
		--end as saldo_iniziale
from [SERCOM].[dbo].MA_ChartOfAccountsBalances
where Account = 020200001
	and BalanceYear >= 2023


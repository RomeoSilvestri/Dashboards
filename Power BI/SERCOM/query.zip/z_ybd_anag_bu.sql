CREATE or ALTER VIEW [dbo].[z_ybd_anag_bu] as
select distinct
	case
		when (sale_ord.TBMW_TipoBusiness = '' or sale_ord.TBMW_TipoBusiness is null) then 'undefined'
		else sale_ord.TBMW_TipoBusiness
	end as business_unit
from [SERCOM].[dbo].[MA_SaleOrd] as sale_ord

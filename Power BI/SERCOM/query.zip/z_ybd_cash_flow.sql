--NEW QUERY FLUSSO CASSA
CREATE or ALTER VIEW [dbo].[z_ybd_cash_flow] as
select 
	cont_det.AccrualDate as periodo
	,cont_det.DebitCreditSign as debit_credit
	,case 
		when cont_det.DebitCreditSign = '4980736'then cont_det.Amount*1
		when cont_det.DebitCreditSign = '4980737'then cont_det.Amount*(-1)
	end as amount
	--,cont_det.Amount
	,cont_det.AccRsn
	--,cont_det.AccRsn as causale
	,cont.AccTpl
	,case
		when cont.AccTpl = 'ACCCLI' then 1
		when cont.AccTpl = 'GC' then 5
		when cont.AccTpl = 'GCIVA' then 4
		when cont.AccTpl = 'INC' then 1
		when cont.AccTpl = 'INC ANTI' then 1
		when cont.AccTpl = 'INCEFF' then 1
		when cont.AccTpl = 'INCNCFOR' then 2
		when cont.AccTpl = 'INSOLUTI' then 1
		when cont.AccTpl = 'PAG' then 2
		when cont.AccTpl = 'PAGANTIC' then 2
		when cont.AccTpl = 'PAGF24' then 4
		when cont.AccTpl = 'PAGRIBA' then 2
		when cont.AccTpl = 'PAGSTIP' then 3
		when cont.AccTpl = 'PREL' then 5
		when cont.AccTpl = 'PRESEFF' then 1
		when cont.AccTpl = 'SPESEB' then 5
		else 'Undefined'
	end as categoria_ordine
	,case 
		when cont.AccTpl in ('ACCCLI','INC','INC ANTI','INCEFF','INSOLUTI','PRESEFF') then '1. Clienti'
		when cont.AccTpl in ('INCNCFOR','PAG','PAGANTIC','PAGRIBA') then '2. Fornitori'
		when cont.AccTpl in ('PAGSTIP') then '3. Stipendi'
		when cont.AccTpl in ('GCIVA','PAGF24') then '4. Imposte e Tasse'
		when cont.AccTpl in ('GC','PREL', 'SPESEB') then '5. Altro'
		else 'Undefined'
	end as categoria
	,case 
		when cont.AccTpl = 'ACCCLI' then 'Acconto Cliente'
		when cont.AccTpl = 'GC' then 'Giroconto'
		when cont.AccTpl = 'GCIVA' then 'Giroconto Iva'
		when cont.AccTpl = 'INC' then 'Incasso Cliente'
		when cont.AccTpl = 'INC ANTI' then 'Incasso Anticipo'
		when cont.AccTpl = 'INCEFF' then 'Incasso Effetti'
		when cont.AccTpl = 'INCNCFOR' then 'Altro Fornitori'
		when cont.AccTpl = 'INSOLUTI' then 'Insoluti Riba'
		when cont.AccTpl = 'PAG' then 'Pagamento Fornitori e Altri'
		when cont.AccTpl = 'PAGANTIC' then 'Pagamento Anticipi'
		when cont.AccTpl = 'PAGF24' then 'Pagamento F24'
		when cont.AccTpl = 'PAGRIBA' then 'Pagamento Fornitori Riba'
		when cont.AccTpl = 'PAGSTIP' then 'pagamento stipendi'
		when cont.AccTpl = 'PREL' then 'Prelievo Contanti'
		when cont.AccTpl = 'PRESEFF' then 'Presentazione Effetti'
		when cont.AccTpl = 'SPESEB' then 'Spese Bancarie'
		else 'Undefined'
	end as categoria_dett
	from [SERCOM].[dbo].MA_JournalEntries as cont
	inner join [SERCOM].[dbo].MA_JournalEntriesGLDetail as cont_det
		on cont.JournalEntryId = cont_det.JournalEntryId
where cont_det.account like '020200001'
	and year(cont_det.AccrualDate) >= 2023
	and cont_det.AccRsn <> 'bia'


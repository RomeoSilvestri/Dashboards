CREATE or ALTER VIEW [dbo].[z_ybd_anag_customer] as
select distinct
	cust.CompanyName 
from [SERCOM].[dbo].[MA_CustSupp] as cust